using System.Configuration;namespace HiyasuApp{public static class DbUtil{
public static string GetConnectionString(){var baseCs=ConfigurationManager.ConnectionStrings["RainbowDBContext01"].ConnectionString;
var mode=(ConfigurationManager.AppSettings["DbMode"]??"Internal").ToLower();
var ds=(mode=="external")?ConfigurationManager.AppSettings["ExternalDbDataSource"]:ConfigurationManager.AppSettings["InternalDbDataSource"];
return ReplaceDataSource(baseCs,ds);} private static string ReplaceDataSource(string cs,string newDs){var parts=cs.Split(';');
for(int i=0;i<parts.Length;i++){var p=parts[i].Trim();if(p.ToLower().StartsWith("data source=")||p.ToLower().StartsWith("server=")){parts[i]="Data Source="+newDs;}}return string.Join(";",parts);} } }