using System;using System.Web;using System.Data.SqlClient;using System.Text;using System.Web.Script.Serialization;
namespace HiyasuApp.Api{public class Health:IHttpHandler{public bool IsReusable{get{return true;}} public void ProcessRequest(HttpContext context){
context.Response.ContentType="application/json; charset=utf-8";context.Response.ContentEncoding=Encoding.UTF8;var ser=new JavaScriptSerializer();
try{var cs=HiyasuApp.DbUtil.GetConnectionString();using(var conn=new SqlConnection(cs)){conn.Open();using(var cmd=new SqlCommand("SELECT TOP 1 GETDATE()",conn)){
var dt=(DateTime)cmd.ExecuteScalar();var ok=new{status="ok",db="connected",serverTime=dt.ToString("yyyy-MM-dd HH:mm:ss")};context.Response.Write(ser.Serialize(ok));}}}
catch(Exception ex){context.Response.StatusCode=500;var err=new{status="error",message=ex.Message};context.Response.Write(ser.Serialize(err));}}}}