using System;using System.IO;using System.Text;using System.Configuration;
namespace HiyasuApp{public static class Logger{private static Encoding Utf8=new UTF8Encoding(true);
private static void Write(string level,string msg){try{var path=ConfigurationManager.AppSettings["LogDir"];
if(!Directory.Exists(path)) Directory.CreateDirectory(path);var file=Path.Combine(path,"app-"+DateTime.Now.ToString("yyyyMMdd")+".log");
using(var sw=new StreamWriter(file,true,Utf8)){sw.WriteLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")+" | "+level+" | "+msg);} }catch{}}
public static void Info(string msg){Write("INFO",msg);} public static void Error(string msg){Write("ERROR",msg);} } }