Param(
  [string]$SiteName = "HiyasuApp_v4_https443_dual",
  [string]$AppPool = "HiyasuApp_v4_https443_dual_AppPool",
  [string]$Path = "C:\Website\HiyasuApp_v4_https443_dual",
  [int]$PortHttp = 80
)
Import-Module WebAdministration

if (!(Test-Path $Path)) { New-Item -ItemType Directory -Force -Path $Path | Out-Null }
$logPath = Join-Path $Path "logs"
if (!(Test-Path $logPath)) { New-Item -ItemType Directory -Force -Path $logPath | Out-Null }
icacls $logPath /grant "IIS_IUSRS:(OI)(CI)(M)" /T | Out-Null

if (!(Test-Path ("IIS:\AppPools\"+$AppPool))) { New-Item IIS:\AppPools\$AppPool | Out-Null }
Set-ItemProperty IIS:\AppPools\$AppPool -Name managedRuntimeVersion -Value "v4.0"
Set-ItemProperty IIS:\AppPools\$AppPool -Name enable32BitAppOnWin64 -Value $false
Set-ItemProperty IIS:\AppPools\$AppPool -Name managedPipelineMode -Value "Classic"

if (!(Test-Path ("IIS:\Sites\"+$SiteName))) {
  New-Item IIS:\Sites\$SiteName -bindings @{protocol="http";bindingInformation="*:$PortHttp:"} -physicalPath $Path | Out-Null
}
Set-ItemProperty IIS:\Sites\$SiteName -Name applicationPool -Value $AppPool

New-NetFirewallRule -DisplayName "HiyasuApp Dual HTTP $PortHttp Inbound" -Direction Inbound -Protocol TCP -LocalPort $PortHttp -Action Allow -Profile Any -ErrorAction SilentlyContinue | Out-Null

iisreset /restart
Write-Host "Installed $SiteName at $Path (HTTP:$PortHttp). Run install-https.ps1 to bind HTTPS:443."
