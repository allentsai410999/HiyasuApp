param(
  [string]$SiteName = "HiyasuApp_v4_https443_dual",
  [string]$DnsName = "rainbowhouse.com.tw",
  [switch]$UseSelfSigned,
  [string]$PfxPath,
  [string]$PfxPassword
)
Import-Module WebAdministration

function Ensure-Firewall443 {[CmdletBinding()] param() 
  try { New-NetFirewallRule -DisplayName "HiyasuApp Dual HTTPS 443 Inbound" -Direction Inbound -Protocol TCP -LocalPort 443 -Action Allow -Profile Any -ErrorAction SilentlyContinue | Out-Null } catch {}
}

function Get-OrCreate-Cert([string]$dns,[switch]$selfSigned,[string]$pfx,[string]$pwd) {
  if ($selfSigned) { Write-Host "Creating self-signed certificate for $dns ..." -ForegroundColor Cyan
    return New-SelfSignedCertificate -DnsName $dns -CertStoreLocation Cert:\LocalMachine\My -KeyExportPolicy Exportable -NotAfter (Get-Date).AddYears(1) }
  elseif ($pfx) { $secure = if ($pwd) { (ConvertTo-SecureString -String $pwd -AsPlainText -Force) } else { $null }
    return Import-PfxCertificate -FilePath $pfx -Password $secure -CertStoreLocation Cert:\LocalMachine\My }
  else { throw "Specify -UseSelfSigned or -PfxPath." }
}

if (-not (Test-Path ("IIS:\Sites\"+$SiteName))) { throw "IIS site $SiteName not found. Run install.ps1 first." }

$cert = Get-OrCreate-Cert -dns $DnsName -selfSigned:$UseSelfSigned -pfx $PfxPath -pwd $PfxPassword
$thumb = $cert.Thumbprint
Write-Host "Using certificate thumbprint: $thumb" -ForegroundColor Green

if (-not (Get-WebBinding -Name $SiteName -Protocol "https" -ErrorAction SilentlyContinue | Where-Object { $_.bindingInformation -eq "*:443:" })) {
  New-WebBinding -Name $SiteName -Protocol https -Port 443 -IPAddress "*" -HostHeader "" | Out-Null
}
$sslPath = "IIS:\SslBindings\0.0.0.0!443"
if (Test-Path $sslPath) { Remove-Item $sslPath -Force -ErrorAction SilentlyContinue }
New-Item -Path $sslPath -Thumbprint $thumb -SSLFlags 0 | Out-Null

Ensure-Firewall443
iisreset /restart | Out-Null
Write-Host "HTTPS ready on https://$DnsName/ (443). Internal HTTP on http://<A機IP>/" -ForegroundColor Green
