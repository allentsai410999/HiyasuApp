Param(
  [string]$SiteName = "HiyasuApp_v4_https443_dual",
  [string]$AppPool = "HiyasuApp_v4_https443_dual_AppPool"
)
Import-Module WebAdministration
if (Test-Path ("IIS:\Sites\"+$SiteName)) { Remove-Item ("IIS:\Sites\"+$SiteName) -Recurse -Force }
if (Test-Path ("IIS:\AppPools\"+$AppPool)) { Remove-Item ("IIS:\AppPools\"+$AppPool) -Recurse -Force }
iisreset /restart
Write-Host "Removed $SiteName and $AppPool"
