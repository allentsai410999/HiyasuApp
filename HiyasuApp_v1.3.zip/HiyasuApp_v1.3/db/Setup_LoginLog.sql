USE [CHIComp01];
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'comLoginLog' AND schema_id = SCHEMA_ID('dbo'))
BEGIN
    CREATE TABLE dbo.comLoginLog
    (
        Id INT IDENTITY(1,1) PRIMARY KEY,
        Email NVARCHAR(200) NULL,
        Success BIT NOT NULL DEFAULT(0),
        RemoteIP NVARCHAR(50) NULL,
        UserAgent NVARCHAR(500) NULL,
        Message NVARCHAR(1000) NULL,
        CreatedAt DATETIME NOT NULL DEFAULT(GETDATE())
    );
    CREATE INDEX IX_comLoginLog_CreatedAt ON dbo.comLoginLog(CreatedAt);
    CREATE INDEX IX_comLoginLog_Email ON dbo.comLoginLog(Email);
END
